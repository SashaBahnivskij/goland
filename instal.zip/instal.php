<?PHP
	/*
		Powered by minibam.ru
		https://vk.com/nikita_kechenkov
	*/
	set_time_limit(0);
	ignore_user_abort(1);
	function download_file($urlDownload = "") {
		if(!file_exists("temp"))
			mkdir('temp');
		if(file_exists("./temp/patch.zip"))
			return true;
		$curlInit = curl_init($urlDownload);
		$fOpen = fopen("./temp/patch.zip", "wb");
		curl_setopt($curlInit, CURLOPT_FILE, $fOpen);
		curl_setopt($curlInit, CURLOPT_HEADER, 0);
		curl_exec($curlInit);
		curl_close($curlInit);
		return fclose($fOpen);
	}
	function recursiveRemoveDir($dir) {
		$includes = new FilesystemIterator($dir);
		foreach($includes as $include) {
			if(is_dir($include) && !is_link($include)) {
				recursiveRemoveDir($include);
			}
			else unlink($include);
		}
		rmdir($dir);
	}
	function curl_get_process($data = []) {
		$ch = curl_init($data['website']);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data['data']);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HEADER, false);
		$result = curl_exec($ch);
		curl_close($ch);
		
		return $result;
	}
	$update = curl_get_process(['website' => "https://minibam.ru/gcms/download/optimal"]);
	if(download_file($update)) {
		$zipArchive = new ZipArchive;
		$resourcePatch = $zipArchive->open("./temp/patch.zip");
		if($resourcePatch === true) {
			$zipArchive->extractTo("./");
			if($zipArchive->close()) {
				recursiveRemoveDir("temp");
				exit("<script language='JavaScript' type='text/javascript'>window.location.replace('/')</script>");
			}
		} else {
			exit('Error install: [Есть проблемы с хостингом. vk.com/minibam]');
		}
	}
?>